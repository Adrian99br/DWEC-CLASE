export interface PrimerComponente {
    id: number
    url: string
    titulo: string
    texto: string
    fecha: string
}
