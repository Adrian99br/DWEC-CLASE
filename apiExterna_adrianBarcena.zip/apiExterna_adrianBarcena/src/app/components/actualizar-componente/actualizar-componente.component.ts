import { Component } from '@angular/core';

@Component({
  selector: 'app-actualizar-componente',
  standalone: true,
  imports: [],
  templateUrl: './actualizar-componente.component.html',
  styleUrl: './actualizar-componente.component.css'
})
export class ActualizarComponenteComponent {

}
