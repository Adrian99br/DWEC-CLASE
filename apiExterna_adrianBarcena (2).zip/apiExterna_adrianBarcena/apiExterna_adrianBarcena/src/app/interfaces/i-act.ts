export interface IAct {
    name: any;
    _id: string; // maneja usuarios para acceder a ellos
    id?: number; // MANEJA EL ARRAY
    first_name: string;
    last_name: string;
    username: string;
    email: string;
    image: string;
    password: string;
}

